到https://tinypng.com/developers註冊API key

使用時帶入即可

使用後會記錄在config.json中

此程式會主動略過非jpg,png檔案，且會將資料夾底下所有圖檔都跑壓縮，並產生與原本的資料夾相同的結構